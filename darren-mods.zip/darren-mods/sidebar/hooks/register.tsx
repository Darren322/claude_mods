import { atom, read, update } from 'claude-code'
import type { EngineInterface, Register } from 'claude-code'

import type {
  CalendarEvent,
  CalendarSnapshot,
  ContextGauge,
  MailFilter,
  MailMessage,
  MailReader,
  MailSnapshot,
  Spec,
  Ticket,
  TicketBoard,
  TicketState,
  TmuxSession,
  TmuxSnapshot,
} from '../types'

// Each one is a top-level pane tab, opened in this order so the tabs read
// Tickets, Tmux, Calendar, Gmail; Blast Radius adds itself after them.
const PANES = [
  { id: 'tickets', title: 'Tickets' },
  { id: 'tmux', title: 'Tmux' },
  { id: 'calendar', title: 'Calendar' },
  { id: 'gmail', title: 'Gmail' },
] as const
type PaneId = (typeof PANES)[number]['id']
const isPaneId = (id: string): id is PaneId => PANES.some(p => p.id === id)
// The single pane before the split; closed at start so a reload leaves no orphan.
const OLD_PANE = 'sidebar'
const BLAST_PANE = 'blast-radius'
const COLUMNS = 34
const SPECS_DIR = 'docs/specs'
const TICKETS_POLL_MS = 4_000
const TMUX_POLL_MS = 5_000
const CALENDAR_POLL_MS = 5 * 60_000
// `$.process.run` takes no shell, so PATH may lack Homebrew.
const TMUX_BINS = ['tmux', '/opt/homebrew/bin/tmux', '/usr/local/bin/tmux']
const CALENDAR_PREFIX = 'mcp__claude_ai_Google_Calendar__'

const ticketState = atom(
  { plugin: 'sidebar', key: 'tickets' } as const,
  { specs: [], stamp: '', error: '' },
  { shape: 'tickets-2' },
)
// Tickets-tab rows whose open/closed state the person flipped from its default.
const ticketsOpen = atom({ plugin: 'sidebar', key: 'ticketsOpen' } as const, [])
const tmuxState = atom(
  { plugin: 'sidebar', key: 'tmux' } as const,
  { sessions: [], error: null },
  { shape: 'tmux-1' },
)
const expanded = atom({ plugin: 'sidebar', key: 'expanded' } as const, [])
const contextState = atom({ plugin: 'sidebar', key: 'context' } as const, null, {
  shape: 'context-1',
})
const mailState = atom(
  { plugin: 'sidebar', key: 'mail' } as const,
  { status: 'connect', filter: 'unread', count: 0, threads: [], next: null, message: null },
  { shape: 'mail-4' },
)
const mailFilter = atom({ plugin: 'sidebar', key: 'mailFilter' } as const, 'unread')
// Wall-clock minute, so the footer's "in 2h" counts down without a refetch.
const minuteState = atom({ plugin: 'sidebar', key: 'minute' } as const, 0)

const READER_CLOSED: MailReader = { id: null, subject: '', status: 'ok', messages: [], message: null, lines: 0 }
const readerState = atom({ plugin: 'sidebar', key: 'reader' } as const, READER_CLOSED, {
  shape: 'reader-1',
})
const calendarState = atom(
  { plugin: 'sidebar', key: 'calendar' } as const,
  { status: 'connect', events: [], message: null },
  { shape: 'calendar-4' },
)
// Week being viewed in the ▦ tab: 0 is this week. calendarState always holds
// week 0 (the footer label and collapsed view use it); calView holds others.
const calWeek = atom({ plugin: 'sidebar', key: 'calWeek' } as const, 0)
const calView = atom(
  { plugin: 'sidebar', key: 'calView' } as const,
  { status: 'loading', events: [], message: null },
  { shape: 'calendar-4' },
)
const calOpen = atom({ plugin: 'sidebar', key: 'calOpen' } as const, null)
const mailLoadingMore = atom({ plugin: 'sidebar', key: 'mailLoadingMore' } as const, false)

// ---------- tmux ----------

async function tmux($: EngineInterface, args: string[]) {
  let lastError = 'tmux not found'
  for (const bin of TMUX_BINS) {
    try {
      return await $.process.run([bin, ...args], { timeoutMs: 5_000 })
    } catch (err) {
      lastError = String(err)
    }
  }
  throw new Error(lastError)
}

async function readTmux($: EngineInterface): Promise<TmuxSnapshot> {
  try {
    const ls = await tmux($, ['list-sessions', '-F', '#{session_name}\t#{session_attached}'])
    if (ls.exitCode !== 0) {
      const isNoServer = /no server|error connecting|no sessions/i.test(ls.stderr)
      return { sessions: [], error: isNoServer ? 'No tmux server running.' : ls.stderr.trim() }
    }
    const lw = await tmux($, [
      'list-windows',
      '-a',
      '-F',
      '#{session_name}\t#{window_index}\t#{window_name}\t#{window_active}',
    ])
    const sessions: TmuxSession[] = ls.stdout
      .split('\n')
      .filter(Boolean)
      .map((line: string) => {
        const [name = '', attached = '0'] = line.split('\t')
        return { name, isAttached: Number(attached) > 0, windows: [] }
      })
    const byName = new Map(sessions.map(s => [s.name, s]))
    for (const line of lw.stdout.split('\n').filter(Boolean)) {
      const [session = '', index = '', name = '', active = '0'] = line.split('\t')
      byName.get(session)?.windows.push({ index, name, isActive: active === '1' })
    }
    return { sessions, error: null }
  } catch (err) {
    return { sessions: [], error: `Could not run tmux: ${String(err)}` }
  }
}

async function refreshTmux($: EngineInterface) {
  const next = await readTmux($)
  const prev = await read($, tmuxState)
  if (JSON.stringify(prev) !== JSON.stringify(next)) await update($, tmuxState, () => next)
}

// ---------- context gauge ----------

async function setContext(
  $: EngineInterface,
  context: { tokens?: number; window: number; percent?: number },
) {
  if (!context.window) return
  const tokens = context.tokens ?? 0
  const percent = Math.round(context.percent ?? (tokens / context.window) * 100)
  const next: ContextGauge = { tokens, window: context.window, percent }
  const prev = await read($, contextState)
  if (JSON.stringify(prev) !== JSON.stringify(next)) await update($, contextState, () => next)
}

function short(n: number) {
  if (n >= 1_000_000) return `${+(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000) return `${Math.round(n / 1_000)}k`
  return String(n)
}

function gaugeColor(percent: number) {
  if (percent < 50) return 'green'
  if (percent < 75) return 'yellow'
  if (percent < 90) return 'magenta'
  return 'red'
}

function gaugeBar(percent: number, cells: number) {
  const filled = Math.min(cells, Math.round((percent / 100) * cells))
  return '▰'.repeat(filled) + '▱'.repeat(cells - filled)
}

// ---------- calendar ----------

const CALENDAR_SERVER = 'claude.ai Google Calendar'

function isoLocal(d: Date) {
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}:00`
}

function dayKey(d: Date) {
  return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`
}

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
const CALENDAR_DAYS = 7
const MAX_EVENTS = 60

function dayLabel(when: Date, now: Date) {
  const tomorrow = new Date(now)
  tomorrow.setDate(now.getDate() + 1)
  if (dayKey(when) === dayKey(now)) return 'Today'
  if (dayKey(when) === dayKey(tomorrow)) return 'Tomorrow'
  return `${DAYS[when.getDay()]} ${when.getDate()} ${MONTHS[when.getMonth()]}`
}

// The connector answers with JSON text: `{ events: [{ summary, start: { dateTime | date } }] }`.
function parseEvents(text: string, now: Date): CalendarEvent[] {
  let body: unknown
  try {
    body = JSON.parse(text)
  } catch {
    return []
  }
  const obj = (body ?? {}) as Record<string, unknown>
  const list = (Array.isArray(body) ? body : (obj.events ?? obj.items ?? [])) as Record<string, unknown>[]
  const out: CalendarEvent[] = []
  for (const ev of list) {
    if (ev.status === 'cancelled') continue
    const start = (ev.start ?? {}) as Record<string, unknown>
    const raw = (start.dateTime ?? start.date) as string | undefined
    if (typeof raw !== 'string') continue
    const isAllDay = !raw.includes('T')
    const when = isAllDay ? new Date(`${raw}T00:00:00`) : new Date(raw)
    const endObj = (ev.end ?? {}) as Record<string, unknown>
    const endRaw = (endObj.dateTime ?? endObj.date) as string | undefined
    const endParsed =
      typeof endRaw === 'string' ? new Date(endRaw.includes('T') ? endRaw : `${endRaw}T00:00:00`).getTime() : NaN
    const endMs = Number.isFinite(endParsed) ? endParsed : when.getTime() + 60 * 60_000
    const hh = String(when.getHours()).padStart(2, '0')
    const mm = String(when.getMinutes()).padStart(2, '0')
    out.push({
      day: dayLabel(when, now),
      isToday: dayKey(when) === dayKey(now),
      time: isAllDay ? 'all-day' : `${hh}:${mm}`,
      title: String(ev.summary ?? '(no title)'),
      startMs: when.getTime(),
      endMs,
      isAllDay,
      id: String(ev.id ?? `${raw}-${out.length}`),
      end: isAllDay ? '' : `${String(new Date(endMs).getHours()).padStart(2, '0')}:${String(new Date(endMs).getMinutes()).padStart(2, '0')}`,
      location: String(ev.location ?? ''),
      description: String(ev.description ?? '')
        .replace(/<[^>]+>/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
        .slice(0, 400),
    })
  }
  return out.slice(0, MAX_EVENTS)
}

async function readCalendar($: EngineInterface, week = 0): Promise<CalendarSnapshot> {
  const names = (await $.tool.list()).map(t => t.name)
  const isConnected = names.some(n => n.startsWith(CALENDAR_PREFIX) && !/authenticate/.test(n))
  if (!isConnected) return { status: 'connect', events: [], message: null }
  const now = new Date(await $.clock.now())
  const start = new Date(now)
  start.setHours(0, 0, 0, 0)
  start.setDate(start.getDate() + week * CALENDAR_DAYS)
  const end = new Date(start)
  end.setDate(start.getDate() + CALENDAR_DAYS)
  try {
    const res = await $.mcp.call(CALENDAR_SERVER, 'list_events', {
      startTime: isoLocal(start),
      endTime: isoLocal(end),
      orderBy: 'startTime',
      pageSize: 50,
    })
    const text = res.content
      .map(block => (block.type === 'text' ? block.text : ''))
      .join('')
    if (res.isError) {
      const isScope = /scope/i.test(text)
      return {
        status: 'error',
        events: [],
        message: isScope
          ? 'No calendar permission. Run /mcp, re-authenticate, and tick the calendar box.'
          : text.slice(0, 200),
      }
    }
    return { status: 'ok', events: parseEvents(text, now), message: null }
  } catch (err) {
    return { status: 'error', events: [], message: String(err).slice(0, 200) }
  }
}

async function refreshCalendar($: EngineInterface) {
  const next = await readCalendar($)
  const prev = await read($, calendarState)
  if (JSON.stringify(prev) !== JSON.stringify(next)) await update($, calendarState, () => next)
  const week = await read($, calWeek)
  if (week !== 0) await refreshCalView($, week)
}

async function refreshCalView($: EngineInterface, week: number) {
  const next = await readCalendar($, week)
  // drop the answer if the person already moved to another week
  if ((await read($, calWeek)) === week) await update($, calView, () => next)
}

async function setWeek($: EngineInterface, week: number) {
  await update($, calWeek, () => week)
  await update($, calOpen, () => null)
  if (week === 0) return
  await update($, calView, (): CalendarSnapshot => ({ status: 'loading', events: [], message: null }))
  await refreshCalView($, week)
}

async function toggleEvent($: EngineInterface, id: string) {
  await update($, calOpen, cur => (cur === id ? null : id))
}

function weekLabel(week: number, nowMs: number) {
  if (week === 0) return 'Next 7 days'
  if (week === 1) return 'The 7 days after'
  if (week === -1) return 'Previous 7 days'
  const start = new Date(nowMs)
  start.setHours(0, 0, 0, 0)
  start.setDate(start.getDate() + week * CALENDAR_DAYS)
  const end = new Date(start)
  end.setDate(start.getDate() + CALENDAR_DAYS - 1)
  const fmt = (d: Date) => `${d.getDate()} ${MONTHS[d.getMonth()]}`
  return `${fmt(start)} – ${fmt(end)}`
}

// ---------- mail (read-only: search_threads, never draft or send) ----------

const MAIL_SERVER = 'claude.ai Gmail'
const MAIL_PREFIX = 'mcp__claude_ai_Gmail__'
// Main inbox: what Gmail's Primary tab shows for this account. The connector
// ignores `category:primary`, and this Primary still lists Updates mail, so
// only Promotions, Social and Forums are left out.
const PRIMARY = '-category:promotions -category:social -category:forums'
// Gmail's resultCountEstimate is not reliable (it answers 201 for anything),
// so show what is loaded, with + when more pages exist.
const mailCount = (mail: MailSnapshot) => `${mail.threads.length}${mail.next !== null ? '+' : ''}`
const MAIL_FILTERS: { id: MailFilter; label: string; query: string; noun: string }[] = [
  { id: 'unread', label: 'unread', query: `in:inbox is:unread ${PRIMARY}`, noun: 'unread' },
  { id: 'read', label: 'read', query: `in:inbox is:read ${PRIMARY}`, noun: 'read' },
  { id: 'all', label: 'all', query: `in:inbox ${PRIMARY}`, noun: 'in inbox' },
  { id: 'starred', label: '★', query: 'is:starred', noun: 'starred' },
  { id: 'spam', label: 'spam', query: 'in:spam', noun: 'spam' },
]
const filterInfo = (id: MailFilter) => MAIL_FILTERS.find(f => f.id === id) ?? MAIL_FILTERS[0]!
const MAIL_ROWS = 20

function decodeEntities(text: string) {
  return text
    .replace(/&#39;/g, "'")
    .replace(/&quot;/g, '"')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
}

async function readMail($: EngineInterface, pageToken?: string): Promise<MailSnapshot> {
  const names = (await $.tool.list()).map(t => t.name)
  const isConnected = names.some(n => n.startsWith(MAIL_PREFIX) && !/authenticate/.test(n))
  const filter = await read($, mailFilter)
  if (!isConnected) return { status: 'connect', filter, count: 0, threads: [], next: null, message: null }
  try {
    const res = await $.mcp.call(MAIL_SERVER, 'search_threads', {
      query: filterInfo(filter).query,
      pageSize: MAIL_ROWS,
      view: 'THREAD_VIEW_MINIMAL',
      ...(pageToken ? { pageToken } : {}),
    })
    const text = res.content.map(block => (block.type === 'text' ? block.text : '')).join('')
    if (res.isError) return { status: 'error', filter, count: 0, threads: [], next: null, message: text.slice(0, 200) }
    const body = JSON.parse(text || '{}') as {
      nextPageToken?: string
      resultCountEstimate?: string | number
      threads?: {
        id?: string
        messages?: {
          sender?: string
          subject?: string
          labelIds?: string[]
          addressDisplayNames?: { displayName?: string; emailAddress?: string }[]
        }[]
      }[]
    }
    const threads = (body.threads ?? []).map(thread => {
      // Name the thread after the latest message someone else sent, as Gmail's
      // list does, not your own reply at the end of it.
      const msgs = thread.messages ?? []
      const received = msgs.filter(m => !(m.labelIds ?? []).includes('SENT'))
      const msg = received[received.length - 1] ?? msgs[msgs.length - 1] ?? {}
      const display = msg.addressDisplayNames?.find(a => a.emailAddress === msg.sender)
      const from = display?.displayName || (msg.sender ?? '').split('@')[0] || '?'
      return {
        id: String(thread.id ?? ''),
        from: decodeEntities(from),
        subject: decodeEntities(msg.subject ?? '(no subject)'),
      }
    })
    const estimate = Number(body.resultCountEstimate ?? threads.length)
    return {
      status: 'ok',
      filter,
      count: Number.isFinite(estimate) ? estimate : threads.length,
      threads,
      next: body.nextPageToken || null,
      message: null,
    }
  } catch (err) {
    return { status: 'error', filter, count: 0, threads: [], next: null, message: String(err).slice(0, 200) }
  }
}

// ---------- mail reader (get_thread, read-only; does not mark as read) ----------

const READER_PAGE = 30

function cleanBody(text: string) {
  const lines = decodeEntities(text)
    .replace(/\r/g, '')
    .replace(/<https?:\/\/[^>\s]+>/g, '↗')
    .replace(/https?:\/\/\S{40,}/g, '↗link')
    .split('\n')
    .map(l => l.trimEnd())
    .filter(l => !/^\[image:[^\]]*\]$/.test(l.trim()))
  const out: string[] = []
  for (const line of lines) {
    if (/^>/.test(line)) continue // quoted reply history
    if (line === '' && (out.length === 0 || out[out.length - 1] === '')) continue
    out.push(line)
  }
  while (out.length && out[out.length - 1] === '') out.pop()
  return out.length ? out : ['(no text body)']
}

function shortDate(iso: string) {
  const d = new Date(iso)
  if (Number.isNaN(d.getTime())) return ''
  const mon = d.toLocaleString('en', { month: 'short' })
  return `${d.getDate()} ${mon} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`
}

async function openThread($: EngineInterface, id: string, subject: string) {
  await update($, readerState, (): MailReader => ({ ...READER_CLOSED, id, subject, status: 'loading', lines: READER_PAGE }))
  let next: MailReader
  try {
    const res = await $.mcp.call(MAIL_SERVER, 'get_thread', { threadId: id, messageFormat: 'PLAIN_TEXT' })
    const text = res.content.map(block => (block.type === 'text' ? block.text : '')).join('')
    if (res.isError) {
      next = { ...READER_CLOSED, id, subject, status: 'error', message: text.slice(0, 200), lines: READER_PAGE }
    } else {
      const body = JSON.parse(text || '{}') as {
        messages?: {
          sender?: string
          date?: string
          snippet?: string
          plaintextBody?: string
          addressDisplayNames?: { displayName?: string; emailAddress?: string }[]
        }[]
      }
      const messages: MailMessage[] = (body.messages ?? []).map(m => {
        const display = m.addressDisplayNames?.find(a => a.emailAddress === m.sender)
        return {
          from: decodeEntities(display?.displayName || m.sender || '?'),
          date: shortDate(m.date ?? ''),
          body: cleanBody(m.plaintextBody ?? m.snippet ?? ''),
        }
      })
      // newest first, so the latest message is what you see on open
      messages.reverse()
      next = { id, subject, status: 'ok', messages, message: null, lines: READER_PAGE }
    }
  } catch (err) {
    next = { ...READER_CLOSED, id, subject, status: 'error', message: String(err).slice(0, 200), lines: READER_PAGE }
  }
  // ignore if the user already went back or opened another thread
  if ((await read($, readerState)).id === id) await update($, readerState, () => next)
}

async function closeThread($: EngineInterface) {
  await update($, readerState, () => READER_CLOSED)
}

async function moreLines($: EngineInterface) {
  await update($, readerState, (r): MailReader => ({ ...r, lines: r.lines + READER_PAGE }))
}

async function setMailFilter($: EngineInterface, next: MailFilter) {
  await update($, mailFilter, () => next)
  await closeThread($)
  await refreshMail($)
}

async function loadMoreMail($: EngineInterface) {
  const cur = await read($, mailState)
  if (cur.status !== 'ok' || cur.next === null || (await read($, mailLoadingMore))) return
  await update($, mailLoadingMore, () => true)
  try {
    const page = await readMail($, cur.next)
    const now = await read($, mailState)
    // only append if the list is still the one we paged from
    if (page.status === 'ok' && now.filter === cur.filter && now.next === cur.next) {
      const seen = new Set(now.threads.map(t => t.id))
      await update($, mailState, (): MailSnapshot => ({
        ...now,
        threads: [...now.threads, ...page.threads.filter(t => !seen.has(t.id))],
        next: page.next,
      }))
    }
  } finally {
    await update($, mailLoadingMore, () => false)
  }
}

// The 5-minute poll leaves a list you paged through alone; ↻ and filters reset it.
async function pollMail($: EngineInterface) {
  const cur = await read($, mailState)
  if (cur.status === 'ok' && cur.threads.length > MAIL_ROWS) return
  await refreshMail($)
}

async function refreshMail($: EngineInterface) {
  const next = await readMail($)
  const prev = await read($, mailState)
  if (JSON.stringify(prev) !== JSON.stringify(next)) await update($, mailState, () => next)
}

// ---------- footer corner: next event ----------

const SOON_MS = 15 * 60_000
const CORNER_TITLE = 22

function untilLabel(ms: number) {
  const mins = Math.max(1, Math.round(ms / 60_000))
  if (mins < 60) return `in ${mins}m`
  const h = Math.floor(mins / 60)
  const m = mins % 60
  return m === 0 || h >= 3 ? `in ${h}h` : `in ${h}h${m}m`
}

function clip(text: string, max: number) {
  return text.length > max ? text.slice(0, max - 1) + '…' : text
}

// The label for the footer's right side, or null when there's nothing to say.
function cornerLabel(cal: CalendarSnapshot, nowMs: number): { text: string; isSoon: boolean } | null {
  if (cal.status !== 'ok') return null
  const timed = cal.events.filter(ev => !ev.isAllDay && ev.endMs > nowMs)
  const next = timed[0]
  const today = new Date(nowMs)
  const isToday = (ms: number) => new Date(ms).toDateString() === today.toDateString()
  if (!next || !isToday(next.startMs)) {
    const later = next ? ` · ${next.day === 'Tomorrow' ? 'tmrw' : next.day.split(' ')[0]} ${next.time}` : ''
    return { text: `▦ free today${later}`, isSoon: false }
  }
  const title = clip(next.title, CORNER_TITLE)
  if (next.startMs <= nowMs) return { text: `▦ now · ${title}`, isSoon: true }
  const gap = next.startMs - nowMs
  return { text: `▦ ${next.time} ${title} · ${untilLabel(gap)}`, isSoon: gap <= SOON_MS }
}

// ---------- tickets (Status tables in docs/specs/*.md, epic folders in docs/specs/*/) ----------

const plain = (text: string) =>
  text.replace(/\*\*|`/g, '').replace(/\[([^\]]*)\]\([^)]*\)/g, '$1').trim()

function normalizeState(raw: string): TicketState {
  const s = raw.toLowerCase()
  if (/done|complete|accepted|merged|wontfix/.test(s)) return 'done'
  if (/progress|review|implement|running|active/.test(s)) return 'active'
  if (/blocked/.test(s)) return 'blocked'
  return 'todo'
}

function parseTicket(cells: string[]): Ticket | undefined {
  const [name = '', rawState = '', notes = ''] = cells.map(plain)
  if (name === '') return undefined
  const match = /^(T\d+[a-z]?)\s+(.*)$/i.exec(name)
  const waiting = /blocked on ([^.;]*)/i.exec(notes)?.[1] ?? ''
  return {
    id: match?.[1] ?? '',
    title: match?.[2] ?? name,
    state: normalizeState(rawState),
    rawState,
    notes,
    waitingOn: waiting.match(/T\d+[a-z]?/gi) ?? [],
    stories: [],
    assignee: '',
    owns: '',
    criteria: [],
  }
}

// A ticket that waits on unfinished tickets reads as blocked.
function markBlocked(tickets: Ticket[]) {
  const done = new Set(tickets.filter(t => t.state === 'done').map(t => t.id))
  for (const ticket of tickets) {
    ticket.waitingOn = ticket.waitingOn.filter(id => !done.has(id))
    if (ticket.state === 'todo' && ticket.waitingOn.length > 0) ticket.state = 'blocked'
  }
}

export function parseSpec(file: string, text: string): Spec | undefined {
  const lines = text.split('\n')
  const heading = lines.find(line => line.startsWith('# ')) ?? file
  const title = plain(heading.replace(/^#\s+/, '').replace(/^Spec:\s*/i, ''))
  const start = lines.findIndex(line => /^##\s+Status\b/i.test(line))
  if (start < 0) return undefined

  const tickets: Ticket[] = []
  let resume = ''
  let rows = 0
  for (const line of lines.slice(start + 1)) {
    if (line.startsWith('## ')) break
    if (/^\*\*Resume here:?\*\*/i.test(line.trim())) {
      resume = plain(line.replace(/^\s*\*\*Resume here:?\*\*:?/i, ''))
      continue
    }
    if (!line.trim().startsWith('|')) continue
    rows += 1
    if (rows === 1 || /^\|[\s:|-]+\|?\s*$/.test(line)) continue // header, separator
    const cells = line.trim().replace(/^\||\|$/g, '').split('|')
    const ticket = parseTicket(cells)
    if (ticket) tickets.push(ticket)
  }

  markBlocked(tickets)
  return { file, title, resume, tickets, isEpic: false, stories: [] }
}

// ---------- epics (docs/specs/<epic>/spec.md + issues/NN-*.md) ----------
// Format: docs/agents/issue-tracker.md in the repo.

// Header values keep `**` (globs in Owns:); only backticks are dropped.
function header(text: string, name: string): string {
  return (new RegExp(`^${name}:[ \\t]*(.*)$`, 'mi').exec(text)?.[1] ?? '').replace(/`/g, '').trim()
}

function section(text: string, heading: string): string {
  const start = new RegExp(`^##\\s+${heading}\\s*$`, 'mi').exec(text)
  if (!start) return ''
  const rest = text.slice(start.index + start[0].length)
  const end = /^##\s+/m.exec(rest)
  return end ? rest.slice(0, end.index) : rest
}

const padId = (id: string) => (/^\d+$/.test(id) ? id.padStart(2, '0') : id)

export function parseEpicTicket(name: string, text: string): Ticket {
  const heading = /^#\s+(.+)$/m.exec(text)?.[1] ?? name
  const rawState = header(text, 'Status') || 'needs-triage'
  const assignee = header(text, 'Assignee')
  return {
    id: padId(/^(\d+)/.exec(name)?.[1] ?? name),
    title: plain(heading.replace(/^\d+\s*[:.-]\s*/, '')),
    state: normalizeState(rawState),
    rawState: rawState.toLowerCase(),
    notes: '',
    waitingOn: [...header(text, 'Blocked by').matchAll(/\b\d+\b/g)].map(m => padId(m[0])),
    stories: [...header(text, 'Stories').matchAll(/\d+/g)].map(m => Number(m[0])),
    assignee: assignee === 'unassigned' ? '' : assignee,
    owns: header(text, 'Owns'),
    criteria: [...text.matchAll(/^\s*- \[( |x|X)\]\s+(.*)$/gm)].map(m => ({
      text: plain(m[2] ?? ''),
      isChecked: m[1] !== ' ',
    })),
  }
}

export function parseEpic(slug: string, spec: string, issues: { name: string; text: string }[]): Spec {
  const title = plain(/^#\s+(.+)$/m.exec(spec)?.[1] ?? slug)
  const stories = [...section(spec, 'User Stories').matchAll(/^\d+\.\s+(.+)$/gm)].map(m => plain(m[1] ?? ''))
  const tickets = [...issues]
    .sort((a, b) => a.name.localeCompare(b.name))
    .map(issue => parseEpicTicket(issue.name, issue.text))
  markBlocked(tickets)
  return { file: `${slug}/spec.md`, title, resume: header(spec, 'Resume here'), tickets, isEpic: true, stories }
}

async function readEpic($: EngineInterface, dir: string, slug: string) {
  const specPath = `${dir}/${slug}/spec.md`
  if (!(await $.fs.exists(specPath))) return undefined
  const specStat = await $.fs.stat(specPath)
  const issueDir = `${dir}/${slug}/issues`
  const files = (await $.fs.exists(issueDir))
    ? (await $.fs.list(issueDir)).filter(f => f.kind === 'file' && /^\d+.*\.md$/.test(f.name))
    : []
  const stamp = `${slug}@${specStat.mtimeMs}[${files.map(f => `${f.name}@${f.mtimeMs}`).sort().join(',')}]`
  return { stamp, slug, specPath, issueDir, files }
}

async function refreshTickets($: EngineInterface) {
  try {
    const dir = `${await $.session.root()}/${SPECS_DIR}`
    if (!(await $.fs.exists(dir))) {
      await update($, ticketState, (): TicketBoard => ({ specs: [], stamp: 'none', error: '' }))
      return
    }
    const entries = (await $.fs.list(dir)).sort((a, b) => a.name.localeCompare(b.name))
    const files = entries.filter(entry => entry.kind === 'file' && entry.name.endsWith('.md'))
    const epics = []
    for (const entry of entries.filter(e => e.kind === 'dir')) {
      const epic = await readEpic($, dir, entry.name)
      if (epic) epics.push(epic)
    }
    const stamp = [...files.map(entry => `${entry.name}@${entry.mtimeMs}`), ...epics.map(e => e.stamp)].join(',')
    if ((await read($, ticketState)).stamp === stamp) return
    const specs: Spec[] = []
    for (const epic of epics) {
      const issues = []
      for (const f of epic.files) issues.push({ name: f.name, text: await $.fs.read(`${epic.issueDir}/${f.name}`) })
      specs.push(parseEpic(epic.slug, await $.fs.read(epic.specPath), issues))
    }
    for (const entry of files) {
      const spec = parseSpec(entry.name, await $.fs.read(`${dir}/${entry.name}`))
      if (spec) specs.push(spec)
    }
    // Unfinished work first; finished specs sink to the bottom.
    const isFinished = (s: Spec) => s.tickets.length > 0 && s.tickets.every(t => t.state === 'done')
    specs.sort((a, b) => Number(isFinished(a)) - Number(isFinished(b)))
    await update($, ticketState, (): TicketBoard => ({ specs, stamp, error: '' }))
  } catch (error) {
    await update($, ticketState, (s): TicketBoard => ({ ...s, error: String(error) }))
  }
}

const TICKET_ICON: Record<TicketState, string> = { done: '✓', active: '●', blocked: '◌', todo: '○' }
const TICKET_COLOR: Record<TicketState, 'success' | 'warning' | 'error' | 'inactive'> = {
  done: 'success',
  active: 'warning',
  blocked: 'error',
  todo: 'inactive',
}

function progressBar(done: number, total: number, width: number) {
  const filled = total === 0 ? 0 : Math.round((done / total) * width)
  return '█'.repeat(filled) + '░'.repeat(width - filled)
}

// ---------- panes ----------

function titleOf(id: PaneId) {
  return PANES.find(p => p.id === id)?.title ?? id
}

async function openAll($: EngineInterface) {
  const results = []
  for (const pane of PANES) results.push(await $.ui.open({ id: pane.id, title: pane.title, columns: COLUMNS }))
  return results
}

// Shown means drawn: an unasked open may wait undrawn in a narrow terminal,
// and the toggle must open that one, not close it.
async function isAnyPlaced($: EngineInterface) {
  return (await $.ui.panes()).some(pane => isPaneId(pane.id) && pane.isPlaced)
}

async function shownPane($: EngineInterface): Promise<PaneId | null> {
  const shown = (await $.ui.panes()).find(pane => pane.isShown && pane.isPlaced)
  return shown && isPaneId(shown.id) ? shown.id : null
}

// Bring one of our tabs back to the front. A plain re-open may only retitle,
// so if that leaves it behind, ask with `focus`, which raises it; Esc then
// hands the keyboard back to the prompt.
async function showPane($: EngineInterface, id: PaneId) {
  await $.ui.open({ id, title: titleOf(id), columns: COLUMNS })
  if ((await shownPane($)) === id) return
  await $.ui.open({ id, title: titleOf(id), columns: COLUMNS, focus: true })
}

async function toggleSession($: EngineInterface, name: string) {
  await update($, expanded, list =>
    list.includes(name) ? list.filter(n => n !== name) : [...list, name],
  )
}

export const register: Register = on => {
  let tmuxTicker: ReturnType<EngineInterface['clock']['every']> | null = null
  let calendarTicker: ReturnType<EngineInterface['clock']['every']> | null = null
  let mailTicker: ReturnType<EngineInterface['clock']['every']> | null = null
  let minuteTicker: ReturnType<EngineInterface['clock']['every']> | null = null
  let ticketTicker: ReturnType<EngineInterface['clock']['every']> | null = null
  // Which of our tabs was in front when Blast Radius opened its pane over it.
  let returnTo: PaneId | null = null

  on('session.start', async ($, e, next) => {
    await $.command.register({ name: 'sidebar', description: 'Show or hide the Tickets, Tmux, Calendar and Gmail tabs' })
    await setContext($, (await $.session.usage()).context)
    await refreshTickets($)
    await refreshTmux($)
    await refreshCalendar($)
    await refreshMail($)
    tmuxTicker?.cancel()
    calendarTicker?.cancel()
    mailTicker?.cancel()
    minuteTicker?.cancel()
    ticketTicker?.cancel()
    const tick = async () => {
      const now = await $.clock.now()
      await update($, minuteState, () => now)
    }
    await tick()
    minuteTicker = $.clock.every(60_000, () => void tick())
    ticketTicker = $.clock.every(TICKETS_POLL_MS, () => void refreshTickets($).catch(() => undefined))
    tmuxTicker = $.clock.every(TMUX_POLL_MS, async () => {
      await refreshTmux($)
      // claude.ai connectors finish loading after session start; keep checking
      // quickly until they appear instead of waiting for the 5-minute poll.
      if ((await read($, mailState)).status === 'connect') await refreshMail($)
      if ((await read($, calendarState)).status === 'connect') await refreshCalendar($)
    })
    calendarTicker = $.clock.every(CALENDAR_POLL_MS, () => void refreshCalendar($))
    mailTicker = $.clock.every(CALENDAR_POLL_MS, () => void pollMail($))
    await $.ui.close({ id: OLD_PANE }).catch(() => undefined)
    void openAll($)

    return next(e)
  })

  // Redraw Tickets at once when Claude edits a spec, without waiting for the poll.
  on('tool.call', async ($, e, next) => {
    const ran = await next(e)
    if (e.tool === 'Write' || e.tool === 'Edit') void refreshTickets($).catch(() => undefined)
    return ran
  })

  // Blast Radius opens its pane with focus and, on close, the surface shows
  // whichever tab it likes. Remember ours and put it back.
  on('ui.open', { id: BLAST_PANE }, async ($, e, next) => {
    const shown = await shownPane($)
    if (shown !== null) returnTo = shown
    return next(e)
  })

  on('ui.close', { id: BLAST_PANE }, async ($, e, next) => {
    const closed = await next(e)
    const target = returnTo
    returnTo = null
    if (target !== null) void showPane($, target).catch(() => undefined)
    return closed
  })

  // The four tabs act as one unit: closing any of them by hand (× or ctrl+x x)
  // closes them all, as the single Sidebar pane did. /sidebar brings them back.
  // Our own $.ui.close calls skip this hook, so this does not recurse.
  on('ui.close', async ($, e, next) => {
    const closed = await next(e)
    if (e.origin.kind !== 'person' || !isPaneId(e.id)) return closed
    for (const pane of PANES) if (pane.id !== e.id) await $.ui.close({ id: pane.id }).catch(() => undefined)
    return closed
  })

  on('ui.render', { component: 'SessionMode' }, async ($, e, next) => {
    const cal = await read($, calendarState)
    const minute = await read($, minuteState)
    const label = cornerLabel(cal, minute || (await $.clock.now()))
    if (label === null) return next(e)
    if (!label.isSoon) return next({ ...e, props: { ...e.props, modes: [...e.props.modes, label.text] } })
    // Under 15 minutes: draw the line ourselves so the event can be yellow.
    const { Box, Text } = $.ui.resolve(e)
    return (
      <Box flexDirection="row">
        {e.props.modes.length > 0 && (
          <Text key="modes" dimColor>
            {e.props.modes.join(' & ')} &{' '}
          </Text>
        )}
        <Text key="next" color="yellow">
          {label.text}
        </Text>
      </Box>
    )
  })

  on('session.measure', async ($, e, next) => {
    await setContext($, e.context)
    return next(e)
  })

  on('command.run', { command: 'sidebar' }, async $ => {
    if (await isAnyPlaced($)) {
      for (const pane of PANES) await $.ui.close({ id: pane.id })
      return { text: 'Tabs hidden. Run /sidebar to show them again.' }
    }
    const opened = await openAll($)
    for (const o of opened) if (!o.isPlaced) return { text: `Tabs are waiting for room: ${o.reason}` }
    return { text: 'Tabs shown.' }
  })

  // The context gauge heads every tab, so it is in view whichever one is shown.
  on('ui.render', { component: 'Pane' }, async ($, e, next) => {
    if (!isPaneId(e.requestId)) return next(e)
    const { Box, Text, Button } = $.ui.resolve(e)
    const ctx = await read($, contextState)
    const columns = Math.max(20, e.props.bodyColumns)

    const gauge =
      ctx === null ? (
        <Text key="ctx" dimColor>
          ctx waiting for first reply
        </Text>
      ) : (
        <Box key="ctx" flexDirection="row">
          <Text color={gaugeColor(ctx.percent)}>{gaugeBar(ctx.percent, 12)}</Text>
          <Text color={gaugeColor(ctx.percent)} bold>
            {' '}
            {ctx.percent}%
          </Text>
          <Text dimColor>
            {' '}
            {short(ctx.tokens)}/{short(ctx.window)}
          </Text>
        </Box>
      )
    const frame = (body: JSX.Element) => (
      <Box flexDirection="column">
        {gauge}
        <Text key="rule" dimColor>
          {'─'.repeat(columns)}
        </Text>
        {body}
      </Box>
    )

    if (e.requestId === 'tickets') {
      const { specs, error } = await read($, ticketState)
      const flipped = new Set(await read($, ticketsOpen))
      const barWidth = Math.max(6, Math.min(20, columns - 14))
      if (specs.length === 0) {
        return frame(
          <Box key="tickets" flexDirection="column">
            <Box key="head" flexDirection="row" justifyContent="space-between">
              <Text key="none" dimColor>
                No specs found in {SPECS_DIR}/.
              </Text>
              <Button key="refresh" label="↻" plain onPress={() => refreshTickets($)} />
            </Box>
            {error !== '' && (
              <Text key="err" color="error">
                {error}
              </Text>
            )}
          </Box>,
        )
      }
      // Unfinished specs start open; stories and ticket details start closed.
      const isOpen = (key: string, byDefault: boolean) => flipped.has(key) !== byDefault
      const toggle = (key: string) => () =>
        void update($, ticketsOpen, list => (list.includes(key) ? list.filter(k => k !== key) : [...list, key]))
      const all = specs.flatMap(s => s.tickets)
      const allDone = all.filter(t => t.state === 'done').length
      const allActive = all.filter(t => t.state === 'active').length

      const ticketRows = (spec: Spec, ticket: Ticket, indent: string, scope: string) => {
        const key = `t:${spec.file}:${scope}:${ticket.id}`
        const open = isOpen(key, false)
        const checked = ticket.criteria.filter(c => c.isChecked).length
        const facts = [
          ticket.assignee !== '' ? `@${ticket.assignee}` : '',
          ticket.criteria.length > 0 ? `☑${checked}/${ticket.criteria.length}` : '',
        ].filter(Boolean)
        const label = `${ticket.id} ${ticket.title}`
        return (
          <Box key={key} flexDirection="column">
            <Button key={key} plain onPress={toggle(key)}>
              {indent}
              <Text color={TICKET_COLOR[ticket.state]}>{TICKET_ICON[ticket.state]} </Text>
              <Text bold={ticket.state === 'active'} dimColor={ticket.state === 'done'}>
                {clip(label, Math.max(8, columns - indent.length - 2))}
              </Text>
            </Button>
            {(facts.length > 0 || ticket.waitingOn.length > 0) && (
              <Text key="facts" wrap="truncate-end">
                {indent}
                {'  '}
                <Text dimColor>{facts.join(' ')}</Text>
                {ticket.state !== 'done' && ticket.waitingOn.length > 0 && (
                  <Text color="error"> ⛔{ticket.waitingOn.join(',')}</Text>
                )}
              </Text>
            )}
            {!spec.isEpic && !open && ticket.state === 'active' && ticket.notes !== '' && (
              <Text key="notes" dimColor wrap="truncate-end">
                {indent}
                {'  '}
                {ticket.notes}
              </Text>
            )}
            {open && (
              <Box key="detail" flexDirection="column" paddingLeft={indent.length + 2}>
                <Text key="state" wrap="wrap">
                  <Text color={TICKET_COLOR[ticket.state]}>{ticket.rawState || ticket.state}</Text>
                  {ticket.stories.length > 0 && <Text dimColor> · {ticket.stories.map(n => `US${n}`).join(', ')}</Text>}
                </Text>
                {ticket.waitingOn.length > 0 && (
                  <Text key="wait" color="error" wrap="wrap">
                    waiting on {ticket.waitingOn.join(', ')}
                  </Text>
                )}
                {ticket.owns !== '' && (
                  <Text key="owns" dimColor wrap="wrap">
                    owns {ticket.owns}
                  </Text>
                )}
                {ticket.notes !== '' && (
                  <Text key="notes" dimColor wrap="wrap">
                    {ticket.notes}
                  </Text>
                )}
                {ticket.criteria.map((c, i) => (
                  <Text key={`c${i}`} wrap="wrap" dimColor={c.isChecked}>
                    {c.isChecked ? '☑' : '☐'} {c.text}
                  </Text>
                ))}
              </Box>
            )}
          </Box>
        )
      }

      const storyGroup = (spec: Spec, key: string, label: string, text: string, served: Ticket[], scope: string) => {
        const open = isOpen(key, false)
        const done = served.filter(t => t.state === 'done').length
        const isMet = served.length > 0 && done === served.length
        const count = served.length === 0 ? '—' : `${done}/${served.length}`
        return (
          <Box key={key} flexDirection="column">
            <Button key={key} plain onPress={toggle(key)}>
              {open ? ' ▾ ' : ' ▸ '}
              <Text color={isMet ? 'success' : served.length === 0 ? 'warning' : undefined} bold>
                {label}
              </Text>
              <Text dimColor> {count} </Text>
              {clip(text, Math.max(6, columns - label.length - count.length - 6))}
            </Button>
            {open && text !== '' && (
              <Text key="story" dimColor wrap="wrap">
                {'   '}
                {text}
              </Text>
            )}
            {open && served.map(t => ticketRows(spec, t, '   ', scope))}
          </Box>
        )
      }

      return frame(
        <Box key="tickets" flexDirection="column">
          <Box key="head" flexDirection="row" justifyContent="space-between">
            <Text key="sum">
              <Text bold>{allDone}</Text>/{all.length} done · <Text color="warning">{allActive}</Text> active
            </Text>
            <Button key="refresh" label="↻" plain onPress={() => refreshTickets($)} />
          </Box>
          {specs.map(spec => {
            const total = spec.tickets.length
            const done = spec.tickets.filter(t => t.state === 'done').length
            const key = `e:${spec.file}`
            const open = isOpen(key, !(total > 0 && done === total))
            const linked = (t: Ticket) => t.stories.some(n => n >= 1 && n <= spec.stories.length)
            const unlinked = spec.tickets.filter(t => !linked(t))
            return (
              <Box key={`spec-${spec.file}`} flexDirection="column" marginTop={1}>
                <Button key={key} plain onPress={toggle(key)}>
                  {open ? '▾ ' : '▸ '}
                  <Text bold dimColor={total > 0 && done === total}>
                    {clip(spec.title, columns - 2)}
                  </Text>
                </Button>
                <Text key="bar">
                  {'  '}
                  <Text color="success">{progressBar(done, total, barWidth)}</Text>
                  <Text dimColor>
                    {' '}
                    {done}/{total} done
                  </Text>
                </Text>
                {open && spec.resume !== '' && (
                  <Text key="resume" dimColor wrap="wrap">
                    {'  '}↳ {spec.resume}
                  </Text>
                )}
                {open && spec.isEpic && spec.stories.length > 0 && (
                  <Box key="stories" flexDirection="column">
                    {spec.stories.map((story, i) =>
                      storyGroup(
                        spec,
                        `s:${spec.file}:${i + 1}`,
                        `US${i + 1}`,
                        story,
                        spec.tickets.filter(t => t.stories.includes(i + 1)),
                        `s${i + 1}`,
                      ),
                    )}
                    {unlinked.length > 0 &&
                      storyGroup(spec, `s:${spec.file}:none`, 'no story', '', unlinked, 'none')}
                  </Box>
                )}
                {open && !(spec.isEpic && spec.stories.length > 0) && (
                  <Box key="flat" flexDirection="column">
                    {spec.tickets.length === 0 && (
                      <Text key="empty" dimColor>
                        {'  '}no tickets yet
                      </Text>
                    )}
                    {spec.tickets.map(t => ticketRows(spec, t, ' ', 'all'))}
                  </Box>
                )}
              </Box>
            )
          })}
          {error !== '' && (
            <Text key="err" color="error">
              {error}
            </Text>
          )}
        </Box>,
      )
    }

    if (e.requestId === 'tmux') {
      const tm = await read($, tmuxState)
      const open = await read($, expanded)
      return frame(
        <Box key="tmux" flexDirection="column">
          <Box key="head" flexDirection="row" justifyContent="space-between">
            <Text key="n" bold>
              tmux · {tm.sessions.length} session{tm.sessions.length === 1 ? '' : 's'}
            </Text>
            <Button key="refresh" label="↻" plain onPress={() => void refreshTmux($)} />
          </Box>
          {tm.error !== null && (
            <Text key="err" dimColor>
              {tm.error}
            </Text>
          )}
          {tm.sessions.map(session => {
            const isOpenRow = open.includes(session.name)
            return (
              <Box key={`s-${session.name}`} flexDirection="column">
                <Button
                  key={`b-${session.name}`}
                  plain
                  label={`${isOpenRow ? '▾' : '▸'} ${session.name} (${session.windows.length})${session.isAttached ? ' ●' : ''}`}
                  onPress={() => void toggleSession($, session.name)}
                />
                {isOpenRow &&
                  session.windows.map(win => (
                    <Text key={`w-${session.name}-${win.index}`} dimColor={!win.isActive}>
                      {'   '}
                      {win.index}: {win.name}
                      {win.isActive ? ' *' : ''}
                    </Text>
                  ))}
              </Box>
            )
          })}
        </Box>,
      )
    }

    if (e.requestId === 'gmail') {
      const mail = await read($, mailState)
      const reader = await read($, readerState)
      const loadingMore = await read($, mailLoadingMore)
      if (reader.id !== null) {
        // flatten messages into lines, then show the first `reader.lines`
        const rows: { key: string; text: string; kind: 'head' | 'body' | 'gap' }[] = []
        reader.messages.forEach((m, mi) => {
          if (mi > 0) rows.push({ key: `g${mi}`, text: '─'.repeat(8), kind: 'gap' })
          rows.push({ key: `h${mi}`, text: `${m.from}${m.date ? ' · ' + m.date : ''}`, kind: 'head' })
          m.body.forEach((line, li) => rows.push({ key: `b${mi}-${li}`, text: line === '' ? ' ' : line, kind: 'body' }))
        })
        const shown = rows.slice(0, reader.lines)
        return frame(
          <Box key="reader" flexDirection="column">
            <Box key="head" flexDirection="row" justifyContent="space-between">
              <Button key="back" label="‹ inbox" plain onPress={() => void closeThread($)} />
              {reader.messages.length > 1 && (
                <Text key="count" dimColor>
                  {reader.messages.length} messages
                </Text>
              )}
            </Box>
            <Text key="subject" bold>
              {reader.subject}
            </Text>
            {reader.status === 'loading' && (
              <Text key="loading" dimColor>
                Loading…
              </Text>
            )}
            {reader.status === 'error' && (
              <Text key="err" dimColor>
                {reader.message ?? 'Could not open this email.'}
              </Text>
            )}
            {reader.status === 'ok' &&
              shown.map(row => (
                <Text
                  key={row.key}
                  bold={row.kind === 'head'}
                  color={row.kind === 'head' ? 'cyan' : undefined}
                  dimColor={row.kind === 'gap'}
                >
                  {row.text}
                </Text>
              ))}
            {reader.status === 'ok' && rows.length > shown.length && (
              <Button
                key="more"
                label={`more ▾ (${rows.length - shown.length} lines)`}
                plain
                dimColor
                onPress={() => void moreLines($)}
              />
            )}
            <Text key="hint" dimColor>
              Ask Claude to draft a reply.
            </Text>
          </Box>,
        )
      }
      return frame(
        <Box key="mail" flexDirection="column">
          <Box key="head" flexDirection="row" justifyContent="space-between">
            <Text key="n" bold>
              {mail.filter === 'spam' ? 'Spam' : mail.filter === 'starred' ? 'Starred' : 'Primary'} ·{' '}
              {mail.status === 'ok' ? `${mailCount(mail)} ${filterInfo(mail.filter).noun}` : '-'}
            </Text>
            <Button key="refresh" label="↻" plain onPress={() => void refreshMail($)} />
          </Box>
          <Box key="filters" flexDirection="row" columnGap={1} marginBottom={1}>
            {MAIL_FILTERS.map(f => (
              <Button
                key={`f-${f.id}`}
                label={f.label}
                plain={mail.filter === f.id ? undefined : true}
                dimColor={mail.filter === f.id ? undefined : true}
                variant={mail.filter === f.id ? 'primary' : undefined}
                onPress={() => void setMailFilter($, f.id)}
              />
            ))}
          </Box>
          {mail.status === 'connect' && (
            <Text key="connect" dimColor>
              Not connected. Run /mcp and pick "claude.ai Gmail".
            </Text>
          )}
          {mail.status === 'error' && (
            <Text key="msg" dimColor>
              {mail.message ?? 'Could not read Gmail.'}
            </Text>
          )}
          {mail.status === 'ok' && mail.threads.length === 0 && (
            <Text key="zero" dimColor>
              {mail.filter === 'unread' ? 'Inbox zero.' : 'Nothing here.'}
            </Text>
          )}
          {mail.status === 'ok' &&
            mail.threads.map((t, i) => (
              <Box key={`t-${i}`} flexDirection="column">
                <Button
                  key="from"
                  plain
                  label={`▸ ${t.from}`}
                  onPress={() => void (t.id ? openThread($, t.id, t.subject) : undefined)}
                />
                <Text key="subj" dimColor wrap="truncate-end">
                  {'  '}
                  {t.subject}
                </Text>
              </Box>
            ))}
          {mail.status === 'ok' && mail.next !== null && (
            <Button
              key="more"
              label={loadingMore ? 'loading…' : `load more ▾ (${mail.threads.length} shown)`}
              plain
              dimColor
              onPress={() => void loadMoreMail($)}
            />
          )}
          <Text key="hint" dimColor>
            Scroll for more · ask Claude to draft a reply.
          </Text>
        </Box>,
      )
    }

    // calendar
    const cal = await read($, calendarState)
    const week = await read($, calWeek)
    const shownCal = week === 0 ? cal : await read($, calView)
    const openEvent = await read($, calOpen)
    const nowMs = (await read($, minuteState)) || (await $.clock.now())
    return frame(
      <Box key="calendar" flexDirection="column">
        <Box key="head" flexDirection="row" justifyContent="space-between">
          <Text key="n" bold>
            {weekLabel(week, nowMs)}
          </Text>
          <Button key="refresh" label="↻" plain onPress={() => void refreshCalendar($)} />
        </Box>
        <Box key="nav" flexDirection="row" columnGap={2} marginBottom={1}>
          <Button key="prev" label="‹ prev" plain dimColor onPress={() => void setWeek($, week - 1)} />
          <Button
            key="today"
            label="today"
            plain={week === 0 ? undefined : true}
            variant={week === 0 ? 'primary' : undefined}
            onPress={() => void setWeek($, 0)}
          />
          <Button key="next" label="next ›" plain dimColor onPress={() => void setWeek($, week + 1)} />
        </Box>
        {shownCal.status === 'connect' && (
          <Text key="connect" dimColor>
            Not connected. Run /mcp and pick "claude.ai Google Calendar".
          </Text>
        )}
        {shownCal.status === 'loading' && (
          <Text key="loading" dimColor>
            Loading…
          </Text>
        )}
        {shownCal.status === 'error' && (
          <Text key="msg" dimColor>
            {shownCal.message ?? 'Could not read the calendar.'}
          </Text>
        )}
        {shownCal.status === 'ok' && shownCal.events.length === 0 && (
          <Text key="free" dimColor>
            Nothing these 7 days.
          </Text>
        )}
        {shownCal.status === 'ok' &&
          shownCal.events.map((ev, i) => {
            const isOpen = openEvent === ev.id
            const isPast = ev.endMs <= nowMs
            return (
              <Box key={`ev-${ev.id}`} flexDirection="column">
                {shownCal.events[i - 1]?.day !== ev.day && (
                  <Text key="day" bold={ev.isToday} dimColor={!ev.isToday}>
                    {ev.day}
                  </Text>
                )}
                <Button
                  key="row"
                  plain
                  dimColor={isPast ? true : undefined}
                  label={`${isOpen ? '▾' : '▸'} ${ev.time} ${ev.title}`}
                  onPress={() => void toggleEvent($, ev.id)}
                />
                {isOpen && (
                  <Box key="detail" flexDirection="column" paddingLeft={4}>
                    <Text key="when" dimColor>
                      {ev.isAllDay ? 'All day' : `${ev.time} – ${ev.end}`}
                    </Text>
                    {ev.location !== '' && (
                      <Text key="where" dimColor>
                        @ {ev.location}
                      </Text>
                    )}
                    {ev.description !== '' && (
                      <Text key="desc" dimColor>
                        {ev.description}
                      </Text>
                    )}
                  </Box>
                )}
              </Box>
            )
          })}
      </Box>,
    )
  })
}
