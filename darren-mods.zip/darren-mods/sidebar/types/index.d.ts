export type TmuxWindow = { index: string; name: string; isActive: boolean }
export type TmuxSession = { name: string; windows: TmuxWindow[]; isAttached: boolean }
export type TmuxSnapshot = { sessions: TmuxSession[]; error: string | null }
export type ContextGauge = { tokens: number; window: number; percent: number }
export type CalendarEvent = {
  day: string
  isToday: boolean
  time: string
  title: string
  startMs: number
  endMs: number
  isAllDay: boolean
  id: string
  end: string
  location: string
  description: string
}
export type CalendarSnapshot = {
  status: 'connect' | 'ok' | 'error' | 'loading'
  events: CalendarEvent[]
  message: string | null
}
export type MailThread = { id: string; from: string; subject: string }
export type MailMessage = { from: string; date: string; body: string[] }
export type MailReader = {
  id: string | null
  subject: string
  status: 'loading' | 'ok' | 'error'
  messages: MailMessage[]
  message: string | null
  lines: number
}
export type MailFilter = 'unread' | 'read' | 'all' | 'starred' | 'spam'
export type MailSnapshot = {
  status: 'connect' | 'ok' | 'error'
  filter: MailFilter
  count: number
  threads: MailThread[]
  next: string | null
  message: string | null
}

export type TicketState = 'done' | 'active' | 'blocked' | 'todo'
export type Criterion = { text: string; isChecked: boolean }
export type Ticket = {
  id: string
  title: string
  state: TicketState
  rawState: string
  notes: string
  waitingOn: string[]
  // Epic tickets only (docs/specs/<epic>/issues/NN-*.md); empty for Status-table rows.
  stories: number[]
  assignee: string
  owns: string
  criteria: Criterion[]
}
// A legacy spec (one file with a Status table) or an epic folder
// (spec.md with numbered User Stories, plus one file per ticket).
export type Spec = {
  file: string
  title: string
  resume: string
  tickets: Ticket[]
  isEpic: boolean
  stories: string[]
}
export type TicketBoard = { specs: Spec[]; stamp: string; error: string }

declare module 'claude-code' {
  interface PluginState {
    sidebar: {
      tmux: Shaped<TmuxSnapshot>
      expanded: string[]
      context: Shaped<ContextGauge | null>
      calendar: Shaped<CalendarSnapshot>
      calWeek: number
      calView: Shaped<CalendarSnapshot>
      calOpen: string | null
      mailLoadingMore: boolean
      mail: Shaped<MailSnapshot>
      mailFilter: MailFilter
      reader: Shaped<MailReader>
      minute: number
      tickets: Shaped<TicketBoard>
      ticketsOpen: string[]
    }
  }
}
