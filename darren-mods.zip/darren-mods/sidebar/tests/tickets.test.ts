import { expect, test } from 'claude-code/testing'

import { parseEpic, parseSpec } from '../hooks/register'

const SPEC = `# Spec: push-to-talk (roadmap 15A, thin slice)

## Status

| Ticket | State | Notes |
| --- | --- | --- |
| T0 16 GB Pi services | done | systemd units installed |
| T1 8 GB Pi cleanup + acceptance | in progress | backup taken |
| T2 Speech-to-text spike | not started | Blocked on T0 (needs Gemma) |
| T3 Speech-to-text server | not started | Blocked on T2 (engine choice) |
| T5 Capture | not started | Independent |

**Resume here:** start T2.

## Goal
| not | a | ticket |
`

test('the Status table becomes tickets with derived blocking', async () => {
  const spec = parseSpec('push-to-talk.md', SPEC)
  expect(spec?.title).toBe('push-to-talk (roadmap 15A, thin slice)')
  expect(spec?.resume).toBe('start T2.')
  expect(spec?.tickets.map(t => [t.id, t.state])).toEqual([
    ['T0', 'done'],
    ['T1', 'active'],
    ['T2', 'todo'],
    ['T3', 'blocked'],
    ['T5', 'todo'],
  ])
  expect(spec?.tickets[3]?.waitingOn).toEqual(['T2'])
})

test('a file without a Status section is skipped', async () => {
  expect(parseSpec('x.md', '# Notes\n\nnothing here')).toBe(undefined)
})

const EPIC = `# Jarvis animation

Status: active
Resume here: start ticket 02

## User Stories
1. As Darren, I want to see Jarvis listening, so that I know it heard me.
2. As Darren, I want it full screen, so that it looks good.

## Solution
3. not a story
`

const ISSUES = [
  { name: '02-web-page.md', text: `# 02: Web page\n\nStatus: in-progress\nStories: US1, US2\nBlocked by: 01, 03\nAssignee: agent:page\nOwns: src/web/**\n\n- [x] serves a page\n- [ ] animates\n` },
  { name: '01-state-stream.md', text: `# 01: State stream\n\nStatus: done\nStories: US1\nBlocked by: None\nAssignee: Darren\n` },
  { name: '03-kiosk.md', text: `# 03: Kiosk launch\n\nStatus: ready-for-agent\nStories: US2\nBlocked by: 02\nAssignee: unassigned\n` },
]

test('an epic folder becomes stories and tickets with header fields', async () => {
  const epic = parseEpic('animation', EPIC, ISSUES)
  expect(epic.isEpic).toBe(true)
  expect(epic.title).toBe('Jarvis animation')
  expect(epic.resume).toBe('start ticket 02')
  expect(epic.stories).toEqual([
    'As Darren, I want to see Jarvis listening, so that I know it heard me.',
    'As Darren, I want it full screen, so that it looks good.',
  ])
  expect(epic.tickets.map(t => [t.id, t.state, t.rawState])).toEqual([
    ['01', 'done', 'done'],
    ['02', 'active', 'in-progress'],
    ['03', 'blocked', 'ready-for-agent'],
  ])
  const page = epic.tickets[1]
  expect(page?.stories).toEqual([1, 2])
  expect(page?.waitingOn).toEqual(['03'])
  expect(page?.assignee).toBe('agent:page')
  expect(page?.owns).toBe('src/web/**')
  expect(page?.criteria).toEqual([
    { text: 'serves a page', isChecked: true },
    { text: 'animates', isChecked: false },
  ])
  expect(epic.tickets[2]?.assignee).toBe('')
})
