import { expect, mock, test } from 'claude-code/testing'

const FILES: Record<string, string> = {
  '/r/docs/specs/animation/spec.md': `# Jarvis animation\n\nResume here: start 02\n\n## User Stories\n1. As Darren, I want to see Jarvis listening, so that I know it heard me.\n`,
  '/r/docs/specs/animation/issues/01-state.md': `# 01: State stream\n\nStatus: done\nStories: US1\nAssignee: Darren\n`,
  '/r/docs/specs/animation/issues/02-page.md': `# 02: Web page\n\nStatus: in-progress\nStories: US1\nBlocked by: 03\nAssignee: agent:page\n\n- [x] serves\n- [ ] animates\n`,
  '/r/docs/specs/animation/issues/03-kiosk.md': `# 03: Kiosk\n\nStatus: ready-for-agent\n`,
  '/r/docs/specs/old.md': `# Spec: old work\n\n## Status\n\n| Ticket | State | Notes |\n| --- | --- | --- |\n| T0 Setup | done | ok |\n`,
}
const DIRS: Record<string, { name: string; kind: 'file' | 'dir' }[]> = {
  '/r/docs/specs': [
    { name: 'animation', kind: 'dir' },
    { name: 'old.md', kind: 'file' },
  ],
  '/r/docs/specs/animation/issues': [
    { name: '01-state.md', kind: 'file' },
    { name: '02-page.md', kind: 'file' },
    { name: '03-kiosk.md', kind: 'file' },
  ],
}
const PANE = {
  plugin: 'sidebar',
  component: 'Pane',
  requestId: 'tickets',
  props: { title: 'Tickets', isFocused: false, bodyColumns: 34, placement: 'dock', scroll: { offset: 0, bodyRows: 40 }, view: {} },
} as const

test('the Tickets tab shows epics, collapsible stories and ticket facts', async ($, on) => {
  mock.clock(on)
  on('session.root', () => ({ value: '/r' }))
  on('fs.exists', (_, e) => ({ value: e.path in DIRS || e.path in FILES }))
  on('fs.list', (_, e) => ({ value: (DIRS[e.path ?? ''] ?? []).map(x => ({ ...x, size: 1, mtimeMs: 1, isLink: false })) }))
  on('fs.stat', () => ({ value: { kind: 'file', size: 1, mtimeMs: 1, isLink: false } }))
  on('fs.read', (_, e) => {
    const text = FILES[e.path]
    if (text === undefined) throw new Error('ENOENT')
    return { value: text }
  })

  for (const surface of ['terminal', 'desktop'] as const) {
    const ui = await $.ui.mount({ ...PANE, surface })
    // ↻ runs the same refresh the poll does; the press settles its work.
    await ui.press({ key: 'refresh' })
    expect((await ui.find({ type: 'Text', text: /done ·/ }))?.text).toMatch(/2\/4 done · 1 active/)
    expect(await ui.find({ type: 'Button', text: /Jarvis animation/ })).toBeTruthy()
    expect(await ui.find({ type: 'Button', text: /US1 1\/2/ })).toBeTruthy()
    expect(await ui.find({ type: 'Button', text: /Web page/ })).toBeFalsy()
    await ui.press({ key: 's:animation/spec.md:1' })
    expect(await ui.find({ type: 'Button', text: /02 Web page/ })).toBeTruthy()
    const facts = await ui.find({ type: 'Text', text: /@agent:page/ })
    expect(facts?.text).toMatch(/☑1\/2.*⛔03/)
    // The unlinked ticket gets its own group; the legacy spec keeps its rows.
    expect(await ui.find({ type: 'Button', text: /no story/ })).toBeTruthy()
    expect(await ui.find({ type: 'Button', text: /T0 Setup/ })).toBeFalsy() // finished spec starts closed
    await ui.press({ key: 's:animation/spec.md:1' })
    await ui.unmount()
  }
})
